export interface User {
  id: string;
  username: string;
  email: string;
  role: 'user' | 'admin';
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
}

export interface Module {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface MetricCard {
  id: string;
  title: string;
  value: string | number;
  change: number;
  icon: string;
}

export interface Alert {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'error' | 'success';
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: string;
}

export interface PredefinedQuestion {
  id: string;
  question: string;
  answer: string;
}
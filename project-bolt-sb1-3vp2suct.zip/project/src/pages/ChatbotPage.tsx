import React, { useState } from 'react';
import ChatbotInterface from '../components/chatbot/ChatbotInterface';
import { ChatMessage, PredefinedQuestion } from '../types';
import { predefinedQuestions } from '../data/mockData';

const ChatbotPage: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = (text: string) => {
    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date().toISOString(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    
    // Find matching predefined question/answer
    const matchedQuestion = predefinedQuestions.find(
      (q) => q.question.toLowerCase() === text.toLowerCase()
    );
    
    // Simulate AI response delay
    setTimeout(() => {
      const botMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: matchedQuestion
          ? matchedQuestion.answer
          : getDefaultResponse(text),
        sender: 'bot',
        timestamp: new Date().toISOString(),
      };
      
      setMessages((prev) => [...prev, botMessage]);
      setIsLoading(false);
    }, 1000);
  };

  const getDefaultResponse = (text: string): string => {
    // Simple keyword matching for non-predefined questions
    const keywords = {
      cost: "Optimizing costs is a primary benefit of AI-powered supply chain management. Our system typically reduces overall supply chain costs by 15-25% through improved forecasting, inventory optimization, and logistics efficiency.",
      logistics: "Our logistics optimization module uses AI to analyze routes, weather, traffic, and delivery priorities to find the most efficient delivery paths, reducing fuel costs and improving delivery times by up to 30%.",
      inventory: "The inventory tracking module uses IoT sensors and AI predictive analytics to maintain optimal inventory levels, reducing carrying costs while preventing stockouts.",
      blockchain: "We use blockchain technology to create immutable records of all supply chain transactions, ensuring data integrity and providing a secure, transparent audit trail for compliance and traceability.",
      integration: "MASSIVE is designed with open APIs that allow integration with most ERP systems, warehouse management systems, and other supply chain software. Our team can provide customized integration solutions for your specific environment.",
    };

    const lowercaseText = text.toLowerCase();
    
    for (const [key, response] of Object.entries(keywords)) {
      if (lowercaseText.includes(key)) {
        return response;
      }
    }

    return "I don't have specific information about that yet. As your AI supply chain assistant, I'm continuously learning. Would you like me to provide general information about how AI can improve supply chain operations?";
  };

  return (
    <div className="h-full">
      <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">MASSIVE AI Assistant</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100%-3rem)]">
        <div className="lg:col-span-2 h-full">
          <ChatbotInterface
            onSendMessage={handleSendMessage}
            messages={messages}
            isLoading={isLoading}
          />
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6 overflow-y-auto">
          <h2 className="text-xl font-bold text-gray-800 mb-4">Suggested Questions</h2>
          <div className="space-y-3">
            {predefinedQuestions.map((q) => (
              <button
                key={q.id}
                onClick={() => handleSendMessage(q.question)}
                className="w-full text-left p-3 bg-gray-50 hover:bg-gray-100 rounded-md text-gray-700 transition-colors"
              >
                {q.question}
              </button>
            ))}
          </div>
          
          <div className="mt-8 p-4 bg-blue-50 rounded-md">
            <h3 className="font-bold text-gray-800 mb-2">Voice Features</h3>
            <p className="text-gray-600 text-sm">
              Click the microphone icon to use voice commands. MASSIVE will recognize your voice gender and respond in a matching voice tone.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatbotPage;
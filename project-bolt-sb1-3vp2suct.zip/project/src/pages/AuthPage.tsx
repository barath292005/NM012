import React from 'react';
import { Database } from 'lucide-react';
import AuthForm from '../components/auth/AuthForm';

const AuthPage: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 px-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <Database className="h-12 w-12 text-blue-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-1">US AI SCM</h1>
          <p className="text-gray-600">Advanced Supply Chain Management with AI</p>
        </div>
        
        <AuthForm />
        
        <div className="mt-8 text-center text-sm text-gray-600">
          <p>Default Admin Credentials:</p>
          <p className="font-medium">Username: MASSIVE <br/> Password: ASCM</p>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
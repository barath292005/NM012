import React from 'react';
import { ArrowRight } from 'lucide-react';
import ModuleCard from '../components/ui/ModuleCard';
import { modules } from '../data/mockData';

interface HomePageProps {
  onNavigate: (path: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white rounded-lg overflow-hidden shadow-xl">
        <div className="px-6 py-12 md:px-12 md:py-20 max-w-4xl">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 leading-tight">
            Transform Your Supply Chain with Artificial Intelligence
          </h1>
          <p className="text-lg md:text-xl text-blue-100 mb-8 max-w-2xl">
            Leverage AI-powered insights, real-time tracking, and predictive analytics to optimize your entire supply chain ecosystem.
          </p>
          <button 
            onClick={() => onNavigate('/dashboard')}
            className="bg-white text-blue-700 hover:bg-blue-50 transition-colors px-6 py-3 rounded-full font-medium flex items-center"
          >
            Explore Dashboard
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </section>

      {/* Key Modules Section */}
      <section>
        <div className="mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Key Modules</h2>
          <p className="text-gray-600 mt-2">Our advanced AI-powered modules work together to streamline your supply chain</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {modules.map((module) => (
            <ModuleCard key={module.id} module={module} />
          ))}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="bg-gray-50 rounded-lg p-8">
        <div className="mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Benefits of AI in Supply Chain</h2>
          <p className="text-gray-600 mt-2">Experience transformative results across your entire operation</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="text-blue-600 font-bold text-4xl mb-2">40%</div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Increased Forecast Accuracy</h3>
            <p className="text-gray-600">AI algorithms analyze historical data, market trends, and external factors to predict demand with unprecedented accuracy.</p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="text-blue-600 font-bold text-4xl mb-2">30%</div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Reduced Inventory Costs</h3>
            <p className="text-gray-600">Maintain optimal inventory levels with real-time tracking and automated reordering based on AI projections.</p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="text-blue-600 font-bold text-4xl mb-2">25%</div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Lower Logistics Costs</h3>
            <p className="text-gray-600">Optimize delivery routes and transportation modes in real-time based on multiple variables and conditions.</p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="text-blue-600 font-bold text-4xl mb-2">60%</div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">Faster Response to Disruptions</h3>
            <p className="text-gray-600">Identify potential disruptions before they impact operations and automatically implement mitigation strategies.</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="text-center py-12">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">Ready to Revolutionize Your Supply Chain?</h2>
        <p className="text-gray-600 mb-8 max-w-2xl mx-auto">Experience the power of AI-driven supply chain management with a personalized demo.</p>
        <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
          <button 
            onClick={() => onNavigate('/dashboard')}
            className="bg-blue-600 hover:bg-blue-700 text-white transition-colors px-6 py-3 rounded-full font-medium"
          >
            View Dashboard
          </button>
          <button 
            onClick={() => onNavigate('/chatbot')}
            className="bg-white border border-blue-600 text-blue-600 hover:bg-blue-50 transition-colors px-6 py-3 rounded-full font-medium"
          >
            Chat with MASSIVE
          </button>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
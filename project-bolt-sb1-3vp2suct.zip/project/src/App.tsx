import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/layout/Navbar';
import Sidebar from './components/layout/Sidebar';
import AuthPage from './pages/AuthPage';
import HomePage from './pages/HomePage';
import DashboardPage from './pages/DashboardPage';
import ChatbotPage from './pages/ChatbotPage';

const AppContent: React.FC = () => {
  const { authState } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentPath, setCurrentPath] = useState('/');

  useEffect(() => {
    // Check auth status on mount
    if (!authState.isAuthenticated) {
      setCurrentPath('/auth');
    }
  }, [authState.isAuthenticated]);

  const handleNavigate = (path: string) => {
    setCurrentPath(path);
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const renderContent = () => {
    if (!authState.isAuthenticated) {
      return <AuthPage />;
    }

    switch (currentPath) {
      case '/':
        return <HomePage onNavigate={handleNavigate} />;
      case '/dashboard':
        return <DashboardPage />;
      case '/chatbot':
        return <ChatbotPage />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {authState.isAuthenticated && (
        <>
          <Navbar onToggleSidebar={toggleSidebar} />
          <Sidebar 
            isOpen={sidebarOpen} 
            onClose={() => setSidebarOpen(false)} 
            onNavigate={handleNavigate}
            currentPath={currentPath}
          />
        </>
      )}
      
      <main 
        className={`${
          authState.isAuthenticated ? 'pt-16 lg:pl-64' : ''
        } transition-all duration-300`}
      >
        {authState.isAuthenticated ? (
          <div className="p-4 md:p-6 max-w-7xl mx-auto">
            {renderContent()}
          </div>
        ) : (
          renderContent()
        )}
      </main>
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
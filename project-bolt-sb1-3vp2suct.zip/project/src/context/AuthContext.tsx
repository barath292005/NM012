import React, { createContext, useContext, useState, useEffect } from 'react';
import { AuthState, User } from '../types';

interface AuthContextType {
  authState: AuthState;
  login: (username: string, password: string) => Promise<boolean>;
  adminLogin: (username: string, password: string) => Promise<boolean>;
  signup: (username: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

const defaultAuthState: AuthState = {
  user: null,
  isAuthenticated: false,
  isAdmin: false
};

const AuthContext = createContext<AuthContextType>({
  authState: defaultAuthState,
  login: async () => false,
  adminLogin: async () => false,
  signup: async () => false,
  logout: () => {}
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>(defaultAuthState);

  useEffect(() => {
    // Check for stored authentication
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser) as User;
        setAuthState({
          user,
          isAuthenticated: true,
          isAdmin: user.role === 'admin'
        });
      } catch (error) {
        localStorage.removeItem('user');
      }
    }
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    // Mock login - in a real app, this would call an API
    if (username && password) {
      const user: User = {
        id: '1',
        username,
        email: `${username}@example.com`,
        role: 'user'
      };
      
      setAuthState({
        user,
        isAuthenticated: true,
        isAdmin: false
      });
      
      localStorage.setItem('user', JSON.stringify(user));
      return true;
    }
    return false;
  };

  const adminLogin = async (username: string, password: string): Promise<boolean> => {
    // Check against default admin credentials
    if (username === 'MASSIVE' && password === 'ASCM') {
      const adminUser: User = {
        id: 'admin1',
        username,
        email: 'admin@aiscm.com',
        role: 'admin'
      };
      
      setAuthState({
        user: adminUser,
        isAuthenticated: true,
        isAdmin: true
      });
      
      localStorage.setItem('user', JSON.stringify(adminUser));
      return true;
    }
    return false;
  };

  const signup = async (username: string, email: string, password: string): Promise<boolean> => {
    // Mock signup - in a real app, this would call an API
    if (username && email && password) {
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        username,
        email,
        role: 'user'
      };
      
      setAuthState({
        user: newUser,
        isAuthenticated: true,
        isAdmin: false
      });
      
      localStorage.setItem('user', JSON.stringify(newUser));
      return true;
    }
    return false;
  };

  const logout = () => {
    setAuthState(defaultAuthState);
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ authState, login, adminLogin, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
import React from 'react';
import { AlertTriangle, CheckCircle2, AlertCircle, Info } from 'lucide-react';
import { Alert } from '../../types';

interface AlertItemProps {
  alert: Alert;
}

const AlertItem: React.FC<AlertItemProps> = ({ alert }) => {
  const getAlertIcon = () => {
    switch (alert.type) {
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'success':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'info':
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  const getAlertClass = () => {
    switch (alert.type) {
      case 'warning':
        return 'border-l-amber-500 bg-amber-50';
      case 'error':
        return 'border-l-red-500 bg-red-50';
      case 'success':
        return 'border-l-green-500 bg-green-50';
      case 'info':
      default:
        return 'border-l-blue-500 bg-blue-50';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className={`border-l-4 p-4 mb-3 rounded-r-md ${getAlertClass()}`}>
      <div className="flex items-start">
        <div className="flex-shrink-0 mt-0.5">
          {getAlertIcon()}
        </div>
        <div className="ml-3 flex-1">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-gray-900">{alert.title}</p>
            <span className="text-xs text-gray-500">{formatTimestamp(alert.timestamp)}</span>
          </div>
          <p className="text-sm text-gray-600 mt-1">{alert.message}</p>
        </div>
      </div>
    </div>
  );
};

export default AlertItem;
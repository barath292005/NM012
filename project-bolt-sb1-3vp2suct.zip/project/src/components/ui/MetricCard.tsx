import React from 'react';
import { TrendingUp, TrendingDown, BarChart3, Box, Clock, Truck } from 'lucide-react';
import { MetricCard as MetricCardType } from '../../types';

interface MetricCardProps {
  metric: MetricCardType;
}

const MetricCard: React.FC<MetricCardProps> = ({ metric }) => {
  const getIcon = () => {
    switch (metric.icon) {
      case 'BarChart3':
        return <BarChart3 className="h-6 w-6 text-blue-600" />;
      case 'Box':
        return <Box className="h-6 w-6 text-blue-600" />;
      case 'Clock':
        return <Clock className="h-6 w-6 text-blue-600" />;
      case 'TrendingUp':
        return <TrendingUp className="h-6 w-6 text-blue-600" />;
      case 'Truck':
        return <Truck className="h-6 w-6 text-blue-600" />;
      default:
        return <BarChart3 className="h-6 w-6 text-blue-600" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 transition-all duration-300 hover:shadow-lg">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-medium text-gray-500">{metric.title}</h3>
          <div className="flex items-baseline mt-1">
            <span className="text-2xl font-bold">{metric.value}</span>
          </div>
        </div>
        <div className="p-2 bg-blue-50 rounded-md">
          {getIcon()}
        </div>
      </div>
      <div className="mt-4 flex items-center">
        {metric.change > 0 ? (
          <>
            <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
            <span className="text-sm font-medium text-green-600">
              {Math.abs(metric.change)}% increase
            </span>
          </>
        ) : (
          <>
            <TrendingDown className="h-4 w-4 text-red-600 mr-1" />
            <span className="text-sm font-medium text-red-600">
              {Math.abs(metric.change)}% decrease
            </span>
          </>
        )}
        <span className="text-sm text-gray-500 ml-2">from last month</span>
      </div>
    </div>
  );
};

export default MetricCard;
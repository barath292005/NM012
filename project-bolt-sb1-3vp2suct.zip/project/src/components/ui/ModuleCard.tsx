import React from 'react';
import { BarChart3, Truck, Package, Factory, Shield } from 'lucide-react';
import { Module } from '../../types';

interface ModuleCardProps {
  module: Module;
}

const ModuleCard: React.FC<ModuleCardProps> = ({ module }) => {
  const getIcon = () => {
    switch (module.icon) {
      case 'BarChart3':
        return <BarChart3 className="h-8 w-8 text-blue-600" />;
      case 'Truck':
        return <Truck className="h-8 w-8 text-blue-600" />;
      case 'Package':
        return <Package className="h-8 w-8 text-blue-600" />;
      case 'Factory':
        return <Factory className="h-8 w-8 text-blue-600" />;
      case 'Shield':
        return <Shield className="h-8 w-8 text-blue-600" />;
      default:
        return <BarChart3 className="h-8 w-8 text-blue-600" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 h-full transition-all duration-300 hover:shadow-lg hover:translate-y-[-4px]">
      <div className="flex flex-col h-full">
        <div className="p-3 bg-blue-50 rounded-md w-fit mb-4">
          {getIcon()}
        </div>
        <h3 className="text-xl font-bold mb-2">{module.title}</h3>
        <p className="text-gray-600 flex-grow">{module.description}</p>
        <button className="mt-4 text-blue-600 font-medium flex items-center hover:text-blue-800 transition-colors">
          Learn more
          <svg className="w-4 h-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default ModuleCard;
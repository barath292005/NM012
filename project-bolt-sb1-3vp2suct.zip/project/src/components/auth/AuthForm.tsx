import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';

type AuthMode = 'login' | 'signup' | 'adminLogin';

interface AuthFormProps {
  defaultMode?: AuthMode;
}

const AuthForm: React.FC<AuthFormProps> = ({ defaultMode = 'login' }) => {
  const [mode, setMode] = useState<AuthMode>(defaultMode);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const { login, signup, adminLogin } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    
    try {
      let success = false;
      
      switch (mode) {
        case 'login':
          success = await login(username, password);
          break;
        case 'signup':
          success = await signup(username, email, password);
          break;
        case 'adminLogin':
          success = await adminLogin(username, password);
          break;
      }
      
      if (!success) {
        setError(mode === 'adminLogin' 
          ? 'Invalid admin credentials' 
          : 'Invalid username or password');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getTitle = () => {
    switch (mode) {
      case 'login':
        return 'Sign In';
      case 'signup':
        return 'Create Account';
      case 'adminLogin':
        return 'Admin Login';
    }
  };

  return (
    <div className="w-full max-w-md">
      <div className="bg-white p-8 rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">{getTitle()}</h2>
        
        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">
              Username
            </label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
          </div>
          
          {mode === 'signup' && (
            <div className="mb-6">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>
          )}
          
          <div className="mb-6">
            <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
              Password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
          </div>
          
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors disabled:bg-blue-300"
          >
            {isLoading ? 'Processing...' : 'Submit'}
          </button>
        </form>
        
        <div className="mt-6 flex flex-col space-y-2">
          {mode !== 'login' && (
            <button
              onClick={() => setMode('login')}
              className="text-sm text-blue-600 hover:text-blue-800 text-center"
            >
              Sign in to your account
            </button>
          )}
          
          {mode !== 'signup' && (
            <button
              onClick={() => setMode('signup')}
              className="text-sm text-blue-600 hover:text-blue-800 text-center"
            >
              Create a new account
            </button>
          )}
          
          {mode !== 'adminLogin' && (
            <button
              onClick={() => setMode('adminLogin')}
              className="text-sm text-blue-600 hover:text-blue-800 text-center"
            >
              Admin login
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthForm;
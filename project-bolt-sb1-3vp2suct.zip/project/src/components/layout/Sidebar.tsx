import React from 'react';
import { X, Home, BarChart2, MessageSquare, Settings, Users, Box } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (path: string) => void;
  currentPath: string;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, onNavigate, currentPath }) => {
  const { authState } = useAuth();

  const sidebarItems = [
    { name: 'Home', path: '/', icon: <Home size={20} /> },
    { name: 'Dashboard', path: '/dashboard', icon: <BarChart2 size={20} /> },
    { name: 'Chatbot', path: '/chatbot', icon: <MessageSquare size={20} /> },
    { name: 'Inventory', path: '/inventory', icon: <Box size={20} /> },
    ...(authState.isAdmin ? [{ name: 'Users', path: '/users', icon: <Users size={20} /> }] : []),
    { name: 'Settings', path: '/settings', icon: <Settings size={20} /> },
  ];

  return (
    <>
      {/* Sidebar Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" 
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div 
        className={`fixed top-0 left-0 h-full w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-50 ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="h-full flex flex-col">
          {/* Sidebar Header */}
          <div className="p-4 border-b flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-800">US AI SCM</h2>
            <button 
              className="lg:hidden text-gray-500 hover:text-gray-700 focus:outline-none" 
              onClick={onClose}
            >
              <X size={20} />
            </button>
          </div>
          
          {/* Sidebar Content */}
          <div className="flex-grow py-6 overflow-y-auto">
            <ul className="space-y-1">
              {sidebarItems.map((item) => (
                <li key={item.path}>
                  <button
                    onClick={() => {
                      onNavigate(item.path);
                      if (window.innerWidth < 1024) {
                        onClose();
                      }
                    }}
                    className={`w-full flex items-center px-4 py-3 text-left ${
                      currentPath === item.path
                        ? 'bg-blue-50 text-blue-700 border-r-4 border-blue-700'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <span className="mr-3">{item.icon}</span>
                    <span className="font-medium">{item.name}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Sidebar Footer */}
          <div className="p-4 border-t">
            <div className="text-sm text-gray-500">
              {authState.isAuthenticated ? (
                <p>Logged in as <strong>{authState.isAdmin ? 'Admin' : 'User'}</strong></p>
              ) : (
                <p>Not logged in</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
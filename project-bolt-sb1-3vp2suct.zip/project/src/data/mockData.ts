import { Module, MetricCard, Alert, PredefinedQuestion } from '../types';
import { 
  BarChart3, 
  Truck, 
  Package, 
  Factory, 
  Shield, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Box
} from 'lucide-react';

export const modules: Module[] = [
  {
    id: '1',
    title: 'AI-Powered Demand Forecasting',
    description: 'Leverage machine learning algorithms to predict future demand with unprecedented accuracy, reducing stockouts and overstock situations.',
    icon: 'BarChart3'
  },
  {
    id: '2',
    title: 'Real-time Inventory Tracking',
    description: 'Connect your inventory to IoT devices for real-time tracking and automatic reordering when stock levels reach predetermined thresholds.',
    icon: 'Package'
  },
  {
    id: '3',
    title: 'Route & Logistics Optimization',
    description: 'Optimize delivery routes using AI algorithms that consider traffic, weather conditions, and delivery priorities to reduce costs and improve delivery times.',
    icon: 'Truck'
  },
  {
    id: '4',
    title: 'Supplier Management',
    description: 'Gain AI-driven insights into supplier performance, risk factors, and opportunities for negotiation to strengthen your supply chain.',
    icon: 'Factory'
  },
  {
    id: '5',
    title: 'Blockchain Security',
    description: 'Ensure data integrity and secure communications through blockchain technology and encrypted channels.',
    icon: 'Shield'
  }
];

export const metrics: MetricCard[] = [
  {
    id: '1',
    title: 'Inventory Turnover',
    value: '12.4',
    change: 5.2,
    icon: 'Box'
  },
  {
    id: '2',
    title: 'On-Time Delivery',
    value: '94%',
    change: 2.1,
    icon: 'Clock'
  },
  {
    id: '3',
    title: 'Forecast Accuracy',
    value: '91%',
    change: 3.7,
    icon: 'TrendingUp'
  },
  {
    id: '4',
    title: 'Supply Chain Costs',
    value: '$1.2M',
    change: -4.3,
    icon: 'BarChart3'
  }
];

export const recentAlerts: Alert[] = [
  {
    id: '1',
    title: 'Potential Supply Disruption',
    message: 'AI detected potential disruption with supplier XYZ due to regional weather conditions.',
    type: 'warning',
    timestamp: '2025-01-15T09:30:00Z'
  },
  {
    id: '2',
    title: 'Inventory Threshold Alert',
    message: 'Product SKU-12345 has reached reorder point. Automatic order created.',
    type: 'info',
    timestamp: '2025-01-15T10:15:00Z'
  },
  {
    id: '3',
    title: 'Delivery Exception',
    message: 'Delivery #DL-9876 is delayed due to unexpected road closure.',
    type: 'error',
    timestamp: '2025-01-15T11:45:00Z'
  },
  {
    id: '4',
    title: 'Forecast Update',
    message: 'Weekly demand forecast has been updated with 3% higher accuracy.',
    type: 'success',
    timestamp: '2025-01-15T13:20:00Z'
  }
];

export const predefinedQuestions: PredefinedQuestion[] = [
  {
    id: '1',
    question: 'What is AI supply chain management?',
    answer: 'AI supply chain management is the application of artificial intelligence technologies to optimize and automate various aspects of the supply chain. This includes demand forecasting, inventory management, logistics optimization, supplier selection, and risk management. By analyzing vast amounts of data and identifying patterns, AI can help make more accurate predictions and recommendations than traditional methods.'
  },
  {
    id: '2',
    question: 'How does AI improve inventory tracking?',
    answer: 'AI improves inventory tracking by using real-time data from IoT sensors and connected devices to maintain accurate inventory levels. Machine learning algorithms can predict optimal inventory levels based on historical data, seasonal trends, and external factors. This reduces holding costs, minimizes stockouts, and prevents overstocking, ultimately leading to improved capital efficiency and customer satisfaction.'
  },
  {
    id: '3',
    question: 'What are the benefits of real-time forecasting?',
    answer: 'Real-time forecasting provides numerous benefits including: reduced inventory costs through more accurate stocking, improved customer satisfaction by preventing stockouts, better production planning, more efficient resource allocation, and enhanced ability to respond to market changes quickly. Our AI-powered forecasting achieves up to 40% higher accuracy than traditional methods.'
  },
  {
    id: '4',
    question: 'How does MASSIVE help with logistics?',
    answer: 'MASSIVE optimizes logistics operations by analyzing multiple variables simultaneously, including traffic patterns, weather conditions, fuel costs, vehicle capacity, and delivery priorities. It can dynamically reroute deliveries in response to real-time conditions, suggest optimal loading configurations, predict maintenance needs for fleet vehicles, and identify the most cost-effective shipping methods for different products and destinations.'
  },
  {
    id: '5',
    question: 'What is the role of IoT in SCM?',
    answer: 'IoT (Internet of Things) devices play a crucial role in modern supply chain management by providing real-time data collection and monitoring capabilities. Smart sensors can track location, temperature, humidity, and condition of goods throughout the supply chain. This enables accurate inventory tracking, quality control, condition monitoring of perishable goods, predictive maintenance, and enhanced visibility across the entire supply chain network.'
  },
  {
    id: '6',
    question: 'How secure is the data in AI SCM?',
    answer: 'Our AI SCM platform employs multiple layers of security, including blockchain technology for immutable record-keeping, end-to-end encryption for all data transfers, role-based access controls, continuous security monitoring, and compliance with industry standards like ISO 27001 and GDPR. All sensitive data is encrypted both in transit and at rest, ensuring your supply chain information remains protected.'
  },
  {
    id: '7',
    question: 'Can MASSIVE integrate with ERP systems?',
    answer: 'Yes, MASSIVE is designed with integration capabilities for major ERP systems including SAP, Oracle, Microsoft Dynamics, and others. We provide standard APIs and connectors that facilitate seamless data exchange, allowing MASSIVE to enhance your existing ERP system with advanced AI capabilities rather than replacing it. This approach minimizes implementation disruption while maximizing the value of your current investments.'
  },
  {
    id: '8',
    question: 'How does AI detect supply chain disruptions?',
    answer: 'AI detects potential supply chain disruptions by continuously monitoring various data sources including supplier performance metrics, global news feeds, weather reports, social media, financial indicators, and transportation network status. Machine learning models identify patterns that precede disruptions and alert users to potential issues before they impact operations, allowing proactive mitigation strategies to be implemented.'
  },
  {
    id: '9',
    question: 'What kind of reports does MASSIVE generate?',
    answer: 'MASSIVE generates a wide range of customizable reports including performance dashboards, forecast accuracy analyses, supplier risk assessments, cost optimization opportunities, carbon footprint calculations, and inventory optimization recommendations. All reports feature interactive visualizations and can be scheduled for automatic delivery or generated on-demand with the ability to drill down into specific details as needed.'
  },
  {
    id: '10',
    question: 'How scalable is this AI SCM system?',
    answer: 'The MASSIVE AI SCM system is highly scalable, built on cloud-native architecture that can handle enterprise-level data volumes and transaction rates. It adapts to organizations of all sizes, from small businesses to global enterprises, with the ability to scale computing resources dynamically based on demand. The system can grow with your business, accommodating increasing SKU counts, additional facilities, and expanding supplier networks without performance degradation.'
  }
];